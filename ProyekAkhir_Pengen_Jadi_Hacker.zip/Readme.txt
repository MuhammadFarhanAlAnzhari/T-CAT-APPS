File ini menjelaskan kelengkapan berkas proyek akhir kami yang berjudul Aplikasi T-CAT. Berkas terdiri dari:


1. File database sql dengan nama database: pboproject
2. Source code project NetBeans
3. Link Youtube tempat unggah video demo proyek akhir: https://youtu.be/vfH3XTus3Xg

Kelompok Pengen Jadi Hacker:
Muhammad Rafly Afrizal Pratama, B, 1402020062
Muhammad Farhan Al-Anzhari, B, 1402020090
Hafidz Putra Herlyansyah, B, 1402020089



======= Seputar Aplikasi ==========

Admin Code: admindata 


Referensi
itext pdf:
https://www.youtube.com/watch?v=SZEhv8tpT6U&list=PLFh8wpMiEi8-Yo59DBCasuVi1M29kQrvn

jar files:
http://www.java2s.com/Code/Jar/i/Downloaditextpdf540jar.htm


javax mail: 
https://www.youtube.com/watch?v=WKOoAQTioNU

http://www.java2s.com/Code/Jar/j/Downloadjavaxmailjar.htm

activation: 
http://www.java2s.com/Code/Jar/a/Downloadactivationjar.htm


Desktop: 
https://docs.oracle.com/javase/7/docs/api/java/awt/Desktop.html

https://stackoverflow.com/questions/5226212/how-to-open-the-default-webbrowser-using-java

JCalendar:
http://www.java2s.com/Code/Jar/j/Downloadjcalendar14jar.htm
